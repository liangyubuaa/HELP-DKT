
source_string = input()

o=source_string.find('are')
n='is'
source_string.replace('are',n)
print(source_string)


