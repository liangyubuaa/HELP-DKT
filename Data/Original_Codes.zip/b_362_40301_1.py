
source_string = input()

strip_string = source_string.strip()
print(source_string.find('day'))
print(source_string.replace('day','time'))
print(strip_string1.split(' '))

