
source_string = input()

source_string.find(day)
source_string.replace(day,time)
source_string.replace(day,time).split( )
print(source_string.find(day))
print(source_string.replace(day,time))
print(source_string.replace(day,time).split( ))

