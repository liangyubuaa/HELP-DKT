
source_string = input()

source_string="ALL day is up"
print(source_string.find("day"))
print(source_string.replace("day","time"))
print(source_string.split(" "))


