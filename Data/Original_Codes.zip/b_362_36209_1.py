

source_string = input()
strip_string1=sourse_string.strip()
title_string2=strip_string1.title()
print(strip_string2)
length=len(strip_string2)
print(length)
