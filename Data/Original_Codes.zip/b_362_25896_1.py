
source_string = input()

m=source_string
print(m.find('day'))
print(m.replace('day','time'))
j=m.replace('day','time')
print(j.split(' '))

