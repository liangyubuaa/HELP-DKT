

source_string = input()
strip_string=source_string.strip()
title_string=strip_string.title()

print(len(title_string))
