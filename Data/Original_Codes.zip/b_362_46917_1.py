
source_string = input()

print(sourse_string.find("day"))
print(sourse_string.replace("day,time"))
print((sourse_string.replace("day,time")).split(" "))


