
first_name = input()
last_name = input()


first_name = 'Zhang'
last_name = 'heng'

full_name = first_name + " " + last_name
print(full_name)

