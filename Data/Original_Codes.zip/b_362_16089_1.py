
first_name = input()
last_name = input()

f=first_name+''+last_name
print(f)

