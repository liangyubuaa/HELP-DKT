
source_string = input()

print("day")
print(source_string.replace("day","time"))
print(source_string.split(" "))

