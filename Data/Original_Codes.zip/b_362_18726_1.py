
source_string = input()

a=source_string.find('day')
b=source_string.replace('day','time')
c=b.split(' ')
print(a,'/n',b,'/n',c,'/n')

