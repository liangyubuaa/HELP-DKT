
first_name = input()
last_name = input()

full_name = first_namec+" "+last_name
print(full_name)

