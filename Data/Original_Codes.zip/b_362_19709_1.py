
source_string = input()

print(source_string.find('day'))
m=source_string.replace('day','time')

print(source_string.split( ))

