

source_string = input()
step1=source_string.strip()
step2=step1.upper()
print(step2)
step3=len(step2)


