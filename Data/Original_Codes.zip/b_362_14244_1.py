
source_string = input()

a_string=source_string.find('day')
print(a_string)
b
print(a_string.replace('day','time'))
print(a_string.split(' '))

