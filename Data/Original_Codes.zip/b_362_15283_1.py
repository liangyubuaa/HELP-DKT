
source_string = input()

print(source_string.find('day'))
replace_source_string=source_string.replace('day','time')
print(replace_source_string)
print(replace_source_string.split(' '))


