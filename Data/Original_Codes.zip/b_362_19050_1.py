
source_string = input()

print(source_string.find("day"))
t=source_string.replace("day","time")
print (t)



