
source_string = input()

print(source_string.find('day'))
x=source_string.replace('day','time')
print(x.split())
print(x)
