
source_string = input()

print(source_string.find('day'))
source_string1=source_string.replace('day,time')
print(source_string1)
source_string2=(source_string1.split(" "))
print(source_string2)

