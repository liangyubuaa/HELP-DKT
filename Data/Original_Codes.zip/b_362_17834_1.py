

source_string = input()
blank_source_string=source_string.strip()
print(blank_source_string)
print(len(source_string))
