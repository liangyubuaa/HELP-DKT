
first_name = input('Hu')
last_name = input('dong')


full_name = first_name+""+last_name
print(full_name)