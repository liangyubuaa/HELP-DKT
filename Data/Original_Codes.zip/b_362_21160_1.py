
source_string = input()

print(source_string.find('day'))
source_string1=source_string.replace(time)
print(source_string1)
print(source_string1.split(' '))

