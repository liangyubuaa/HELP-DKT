

source_string = input()
strip_string1=source_string.strip()
title_string=source_string1.title()
length=len(title_string)
print(title_string)
print(length)
