
source_string = input()

print(source_string.find("da"))
print(source_string.replace("day","time"))
print(source_string.replace("day","time").split(separator))

