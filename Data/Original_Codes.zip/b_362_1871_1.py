
source_string = input()

step1=source_string.find('day')
print(step1)
step2=source_string.replace('day','time')
print(step2)
step4=step1_split(' ')
print(step4)

