

source_string = input()
blank_source_string=source_string.strip
upper_source_string.strip=source_string.strip.upper
print(source_string.strip.upper)