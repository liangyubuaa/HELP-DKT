
first_name = input()
last_name = input()

full = 'first-name' +  '.last-name'
print(full-name)
