
source_string = input()
print (source_string.find('day'))
a = source_string.raplace('day','time')
print (a)
print (a.split(''))




