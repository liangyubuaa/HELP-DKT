
source_string = input()

print(source_string.find(sub_string))
print(source_string.replace(old_string, new_string))
print(source_string.split(blank))

