
first_name = input(hu)
last_name = input(dong)

first_name = input(hu)
last_name = input(dong)
result_string = source_string1 + source_string2
