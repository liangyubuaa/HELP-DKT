
source_string = input()

print(source_string.find('day'))
print(source_string.relace('day','time'))
abc=source_string.relace('day','time')
print(abc.split(' '))

