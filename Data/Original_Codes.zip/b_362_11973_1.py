

source_string = input()
title_source_string=source_string.title()
print(title_source_string+"\n")
print(len(source_string))
