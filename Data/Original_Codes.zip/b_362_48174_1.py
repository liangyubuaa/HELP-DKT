

source_string = input()
a=[item.title() for item in source_string]
print(a)
print(len(source_string))
