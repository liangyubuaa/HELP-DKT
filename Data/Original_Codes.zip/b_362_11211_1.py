
source_string = input()

print(source_string.find("day"))

print(source_string.replace('day','time'))

print(source_string.split(' '))


