
source_string = input()

print(source_string.find(day))
source_string.replace("day","time")
b=source_string.split(" ")
print(b)

