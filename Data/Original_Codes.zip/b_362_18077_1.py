
source_string = input()

a=source_string.find('day')
print(a)
print(source_string.repalce(day,time))
print(source_string.spilt(' '))


