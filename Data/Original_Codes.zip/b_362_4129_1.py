
source_string = input()

step1=source_string.find('day')
print(step1)
step2=source_string.replace('day','time')
print(step2)
step3=step2.split('')
print(step3)


