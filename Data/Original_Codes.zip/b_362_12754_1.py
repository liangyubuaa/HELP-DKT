
source_string = input()

source_string.find(day)
source_string.replace(day,time)
print(source_string.split(" "))

