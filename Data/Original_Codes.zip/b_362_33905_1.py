
source_string = input()

print(source_string.find('day'))
source_string.replace('day','time')
print(source_string.replace('day','time'))
print(source_string.split('/'))


