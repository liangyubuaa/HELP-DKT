
source_string = input()

a=source_string.find(day)
b=source_string.replace()
c=source_string.split()
print(a)
print(b)
print(c)

