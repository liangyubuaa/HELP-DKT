
guests = []
while True:
	try:
		guest = input()
		guests.append(guest)
	except:
		break

	
guests=['Zhang san','Li si','Wang wu','Zhao liu']
guests.append('Hu qi')
del guests[0]
guests[1]='Wang shi'

 
