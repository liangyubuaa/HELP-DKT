

source_string = input()
a=' source_string  '
b=a.strip( )
c=b.upper()
print(c)
print(len(c))

