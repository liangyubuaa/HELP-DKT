
source_string = input()

print(source_string.find('day'))
print(source_string.replace('day','time'))
s=source_string.replace('day','time')
print(s.spilt(' '))


