

source_string = input()
strip_string = source_string.srrip()
title_string = strip_string.title()
print(title_string)
length = len(title_string)
print(length)
