
source_string = input()

print(source_string.find('day'))
source_string=source_string.replace('day,time')
print(sourrce_string)
print(source_string.split(' '))

