
source_string = input()

a=source_string.find('day')
print(a)
b=source_string.replace('day','time')
print(b)
c=b.split(' ')
print(c)

