
first_name = input()
last_name = input()

first_name = input("Hu")
last_name = input("dong")
full_name=first_name+" "+last_name

