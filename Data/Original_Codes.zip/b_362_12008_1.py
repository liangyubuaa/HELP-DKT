
source_string = input()

source_string.find(sub_string)
print(source_string.find())
print(source_string.find())


