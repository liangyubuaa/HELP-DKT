

source_string = input()
blank_source_string=source_string.strip()
title_blank_source_string=blank_source_string.upper()
print(upper_blank_source_string)