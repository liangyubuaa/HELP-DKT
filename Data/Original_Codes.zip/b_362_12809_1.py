
source_string = input()

print(source_string.find(day))
print(source_string.replace('day','time'))
source0_string = source_string.replace('day','time')
print(source0_string.split( ))

