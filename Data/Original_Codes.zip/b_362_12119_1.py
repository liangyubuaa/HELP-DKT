

source_string = input()
source_string=source_string.st('^')
print(source_string.title())
print(len(source_string))
