
source_string = input()

a=source_string.repalce('day','time')
print(source_string.find('day'))
print(a)
print(a.split(' '))


