
guests = []
for i in range(4):
    guest = input()
    guests.append(guest)

to_add = input()





