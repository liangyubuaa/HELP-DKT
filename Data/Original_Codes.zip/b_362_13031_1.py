
first_name = input(Hu)
last_name = input(Dong)

full_name = first_name + " " + last_name
print(full_name)

first_name = input(Hu)
last_name = input(Dong)

full_name = first_name + " " + last_name
print(full_name)

