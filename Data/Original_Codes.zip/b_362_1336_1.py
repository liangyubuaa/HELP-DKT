

source_string = input()
a=source_string.strip(target_char)
a=a.upper()
print(a)
a=len(a)
print(a)


