
source_string = input()

print(source_string.find('day'))
print(source_string.replace('time','day'))
print(source_string.split('/'))

