

source_string = input()
upper_source_string = source_string.upper()
lower_source_string = source_string.lower()
title_source_string = source_string.title()
print (source_string+"\n")
print (upper_source_string+"\n")
print (lower_source_string+"\n")
print (title_source_string+"\n")


