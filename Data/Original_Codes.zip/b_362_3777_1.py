1.

first_name = input()
last_name = input()

full_name = first_name + " " + last_name
print(full_name)
