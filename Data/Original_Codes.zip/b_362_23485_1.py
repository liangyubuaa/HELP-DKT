

source_string = input()
step1_string=source_string.strip()
step2_string=step1_string.title()
length=len(step2_string)
print(step1_string)
print(length)
