

source_string = input()
x1=source_string.strip()
x2=source_string.title()
x3=len(x2)
print(x1)
print(x2)
print(x3)
