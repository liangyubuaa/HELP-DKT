
source_string = input()

source
print(source_sting.find(day))
print(source_string.replace(day,time))
print(source_string.split( ))

