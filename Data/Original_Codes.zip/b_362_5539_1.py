
source_string = input()

print(source_string.find("day"))
print(source_string.replace("day","time"))
string1=source_string.replace("day","time")
print(string1.split("/"))

