
source_string = input()

print(source_string.find("day"))
source_string=source_string.replace("day","time")
print(source_string)
print(source_string.split( ))

