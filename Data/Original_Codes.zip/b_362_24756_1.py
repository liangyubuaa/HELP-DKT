
source_string = input()

print(source_string.find(day))
a=source_string.replace(day,time)
print(a)
print(a.split(" "))

