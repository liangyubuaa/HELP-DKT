
source_string = input()

find_string=source_string.find(d)
replace_string=source_string.replace('day','time')
split_string=replace_string.split(' ')
print(find_string)
print(replace_string)
print(split_string)