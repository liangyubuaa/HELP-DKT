
guests = []
while True:
	try:
		guest = input()
		guests.append(guest)
	except:
		break

	
guests.append(guest)
guests.pop(0)
guests[1]=guest
print()
