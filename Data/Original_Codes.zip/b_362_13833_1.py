
source_string = input()

print(source_string.find(' '))
print(source_string.replace(' ',' '))
print(source_string.split('/'))


