sub_string= input()
source_string = input()
new_string= input()

source_string.replace(old_string, new_string)

