
source_string = input()

print(source_string.find("day"))
print(source_string.place("day","time"))
print(source_string.place("day","time").split( ))

