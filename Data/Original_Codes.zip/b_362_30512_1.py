
source_string = input()

a=source_string
b=a.find("day")
print(b)
c=a.replace(day,time)
print(c)
d=c.split( )
print(d)

