
source_string = input()

x=source_string.find('day')
print(x)
source_string.replace(day,time)
print(source_string)
source_string.split('')
print(source_string)


