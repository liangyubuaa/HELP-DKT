

source_string = input()
hello_world= '  the word is big  ' 
blank_hello_world = hello_world.strip()
print (blank_hello_world)
title_blank_hello_world = blank_hello_world.title
print (title_blank_hello_world+"\n")
length = len(title_blank_hello_world)
print (length)
