

source_string = input()
s1=source_string.strip()
s2=s1.title()
print(s2)
print(length(s2))


