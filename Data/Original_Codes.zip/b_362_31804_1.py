
source_string = input()

x=source_string.find()
y=source_strnig.replace()
z=y.split()
print(x)
print(y)
print(z)
      