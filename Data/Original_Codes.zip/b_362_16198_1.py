

source_string = input()
blank_source_string = source_string.strip()
title_source_string =source_string.title()
length = len(source_string)
print(source_string)

