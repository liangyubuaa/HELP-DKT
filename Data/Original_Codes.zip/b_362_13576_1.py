
source_string = input()

print(source_string.find('t'))
print(source_string.replace('are','is'))


