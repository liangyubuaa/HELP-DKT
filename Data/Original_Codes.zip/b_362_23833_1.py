
source_string = input()

print(source_string.find('day'))
new_string=source_string.replace('day','time')
print(new_string)
print(new_string.split(" "))

