
source_string = input()

source_string.find(sub_string)
print(source_string.find(sub_string))
print(source_string.replace(sub_string,new_string))

print(source_string.split( ))

