

source_string = input()
Blank_source_string = Source_string.strip()
Char_source_string = Source_string.strip()

print(Blank_source_string)
print(cChar_source_string)