
source_string = input()

print()
source_string.find(day_string)
source_string.repiace(day_string,time_string)
source_string.split(separator)

