

source_string = input()
a='Where there is a will,there is a way'
blank_a=a.strip()
print(blank_a)
b=blank_a
title_b=b.title()
print(title_b+"\n")
c=title._b
d=len(c)
print(d)
