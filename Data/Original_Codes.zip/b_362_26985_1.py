

source_string = input()
strip_string = source_string.strip()
title_string = strip_string.title()
length = len(title_string)
print(length)

