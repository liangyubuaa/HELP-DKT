

source_string = input()
blank_source_string = source_string.strip()
title_string = source_string.title()
print(title_string+"\n")
length = len(source_string)
print(length)

