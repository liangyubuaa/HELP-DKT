
source_string = input()

source_string = source_string.find('day')
source_string = source_string.replace('day','time')
pr
print(source_string.split(' '))

